package com.kh.practice.chap01.run;

import com.kh.practice.chap01.controlpractice.controlpractice;

public class Run {

	public static void main(String[] args) {
		controlpractice c = new controlpractice();
		c.practice10();
	}

}
