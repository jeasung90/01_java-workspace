package com.kh.practice.run;

import com.kh.practice.func.OperatorPractice;

public class Run {

	public static void main(String[] args) {
		
		OperatorPractice o = new OperatorPractice();
		//o.practice1();
		//o.practice2();
		//o.practice3();
		//o.practice4();
		//o.practice5();
		//o.practice6();
		//o.practice7();
		o.practice11();
		
		
		
		
	}

}
